
functions.add("test", function() {
    return new tree.Anonymous( "PASS" );
});
